import boto3
import datetime

exporters = {}

def handler(event, context):
    # client = boto3.client('batch')
    print("running")
    s3 = boto3.resource('s3')
    objs = s3.list_objects(Bucket='lamba-run-on-success', Prefix="status/")
    for obj in objs["Contents"]:
        key = obj["Key"]
        
        status = key.split('/')[-1]

        if status == '_SUCCESS':
            print("FOUND")
        else:
            print("NO _SUCCESS")